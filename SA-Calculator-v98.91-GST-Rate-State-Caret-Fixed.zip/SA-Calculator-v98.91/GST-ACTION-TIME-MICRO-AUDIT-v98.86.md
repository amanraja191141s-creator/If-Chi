# GST Calculator — Action-time micro audit (v98.86)

## Source evidence from the 23.49-second recording

- At approximately 00:05, amount `222` shows a caret immediately after the digits and a second coral vertical caret at the far-right edge of the field.
- The GST rate field also shows an additional coral vertical caret at its far-right edge.
- The GST amount card and rate card consume excessive vertical space while the numeric dock is open.
- The lower place-of-supply row is partly hidden behind/under the dock while editing.
- At approximately 00:20, the 5% and 18% quick-rate controls visibly intrude into the `Different State` button row; the labels overlap and become unreadable.
- After calculation, the dark result panel shows the final IGST row clipped at the lower edge; the result surface is inconsistent with the light GST form.

## Root causes confirmed in source

1. `index.html` supplied a sibling `.input-cursor` in each GST field, while `renderToolInputValue()` inserted another cursor inside `.input-text`. Both were styled visible, producing the duplicate caret.
2. The CSS file contained multiple appended GST layout revisions. Some revisions changed card display/height/grid placement without fully resetting prior constraints. This allowed rate shortcuts and place controls to compete for space in WebView layout.
3. The result card had `overflow:hidden`, a fixed visual row treatment, and multiple later display overrides; lower rows could be cut off rather than exposed by the parent scroll container.
4. Caret mapping's separator filter used an escaped character-class expression that did not correctly treat whitespace as a separator. It is corrected to a whitespace-aware expression.

## v98.86 corrections

- One cursor node per GST field, nested inside the text span where the formatter positions it.
- Raw numeric caret index maps to formatted display index while skipping grouping commas, symbols, and whitespace.
- Dedicated amount, mode, rate, and place rows in normal document flow.
- Explicit 3-column rate card: icon, rate field, quick-rate actions.
- Quick-rate buttons are static-positioned and constrained to their own grid column.
- Mode and state controls have independent two-column rows and no inherited transforms/absolute offsets.
- Result card is content-height-driven, has no clipping overflow, and remains inside the vertically scrollable GST content area.
- GST stays light regardless of global theme, without changing the global theme for other tools.

## Verification summary

Automated release suite: 120 passed, 0 failed. Android web bundle preparation, JavaScript syntax, workflow parsing, test-path presence, release identity, service-worker namespace, and root/`www/` synchronization passed.

## Not verified on physical device

Actual Android touch coordinates, cursor rendering on the user's WebView, orientation changes, device-specific viewport insets, APK installation, and runtime performance were not tested. These must be checked on the target phone and by a new GitHub Actions run.
