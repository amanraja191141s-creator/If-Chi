# SA Calculator v98.91 — GST Rate Layout, Different State & Caret Audit

## Screenshot-derived target
- Move `GST Rate(%)` to the upper marked position beside the percent icon.
- Keep `Add rate`, `5%`, and `18%` together on one lower row.
- Keep the amount card and keypad workflow intact.
- Make Same State / Different State selection and the corresponding GST result rows consistent.

## Findings in v98.90 source
1. The GST card had multiple appended layout rules with competing grid/flex geometry. The visible label could be displaced from its intended upper position.
2. Result rows use the HTML `hidden` attribute, while generic result-row CSS forces `display:flex !important`; that can defeat the browser's normal hidden rendering and leave the wrong tax breakdown visible.
3. Initial static component-rate labels were inconsistent (`SGST 2.5%` and `CGST 4.5%`) before a valid calculation populated the labels.
4. GST place selection already fed the calculation model (same state splits tax into SGST/CGST; different state assigns the full tax to IGST), but the UI hiding contract needed explicit CSS enforcement.
5. v98.90 already contained custom GST caret rendering, explicit empty-state placeholders, horizontal input scrolling, and native selection/callout suppression. These behaviours were retained and regression-checked.

## Changes in v98.91
- Added a final authoritative layout override: GST Rate label is left-aligned in the upper row; Add rate and the 5%/18% quick-rate buttons are in a single lower row.
- Added responsive geometry for narrow screens.
- Added an explicit `[hidden] { display:none !important }` rule scoped to GST result rows, so Different State hides SGST/CGST and shows IGST; Same State does the reverse.
- Normalized place selection from the button's data value and synchronized active classes and `aria-pressed` values for both choices.
- Removed misleading initial percentage values from the static SGST/CGST/IGST labels; valid calculations populate exact rates.
- Preserved the app-managed cursor, placeholder, quick-rate caret placement, and horizontal overflow behaviour.
- Bumped release identity to `1.99.05-v98.91`, Android versionCode `1099111`, and a new service-worker cache namespace.
- Added `tests/gst-rate-layout-state-regression-v9891.test.mjs` and included it in the release test command and workflow file checks.

## GST calculation behaviour
- With GST (exclusive): entered amount is taxable base; GST is added to get gross amount.
- Without GST (inclusive): entered amount is gross; GST component is extracted from it.
- Same State: tax is divided equally between SGST and CGST.
- Different State: the full GST amount is shown as IGST; SGST and CGST rows are hidden.

## Verification limits
Automated source/regression checks and package integrity are recorded in the build report. No physical Android device session, Play Store build/signing, or remote GitHub Actions execution is claimed. A browser screenshot render is not claimed as passed. Device-specific touch feel, font metrics, safe-area behaviour, and visual pixel alignment should still be confirmed on the target phone.
