import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const css = fs.readFileSync(path.join(root, 'assets/css/tool-reference-ui.css'), 'utf8');

test('tool launcher has stable three-column geometry and accessible labels', () => {
  const cards = [...html.matchAll(/class="premium-tool-card"[^>]*data-tool-screen="([^"]+)"[^>]*aria-label="([^"]+)"/g)];
  assert.equal(cards.length, 12);
  for (const [, screen, label] of cards) {
    assert.ok(screen && label, `missing launcher metadata for ${screen}`);
  }
  assert.match(css, /#screen-tools \.tools-reference-grid\s*\{[^}]*grid-template-columns:\s*repeat\(3,/s);
  assert.match(css, /#screen-tools \.premium-tool-card\s*\{[^}]*min-height:\s*108px/s);
});

test('tool UI is theme-safe and does not force white surfaces in dark mode', () => {
  assert.match(css, /body\[data-theme="dark"\][\s\S]*--sa-tool-card:\s*#151c26/);
  assert.match(css, /#tool-keypad-dock \.tool-keypad-grid > \.key-btn\s*\{[\s\S]*background:\s*var\(--sa-tool-key\)/);
  assert.match(css, /#screen-viewport \.reference-form-card,[\s\S]*background:\s*var\(--sa-tool-card\)/);
  assert.match(css, /body\[data-theme="dark"\] #screen-viewport \.date-event-dialog/);
});

test('unit-price tool opens clean without seeded example values', () => {
  const ids = ['up-p-a','up-q-a','up-p-b','up-q-b'];
  for (const id of ids) {
    const re = new RegExp(`id="${id}"[\\s\\S]*?<span class="input-text">([^<]*)<\\/span>`);
    const m = html.match(re);
    assert.ok(m, `missing ${id}`);
    assert.equal(m[1], '', `${id} still contains a demo value`);
  }
});
