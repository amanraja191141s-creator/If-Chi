# Build Verification — SA Calculator v98.87

## Release identity
- Package: `1.99.01-v98.87`
- Android versionCode: `1099107`
- Service Worker cache: `sa-calculator-v98-87-gst-pixel-geometry-v9887`

## Automated verification
- `npm test`: **124/124 passed, 0 failed** (serialized with `--test-concurrency=1` to avoid resource contention in CI).
- `npm run build:web`: passed; 13 required Android web assets verified.
- `node --check assets/js/app.js`: passed.
- `node --check assets/js/localization.js`: passed.
- `node --check assets/js/theme-bootstrap.js`: passed.
- Active workflow YAML: **3/3 parsed** and byte-identical (`.github/workflows/main.yml`, `Android-Workflow-v98.87.yml`, `sa-calculator-v98.87-android.yml`).
- Release test entry points: **22/22 exist**, no duplicate paths.
- Root and `www/` copies: **8/8 byte-identical** for the web shell and runtime assets.

## ZIP verification
- ZIP integrity check: passed (verified after packaging).

## Not performed
- No physical Android device/WebView touch, rotation, safe-area or performance test was performed in this environment.
- No remote GitHub Actions run and no Android APK build were executed. The workflow is prepared for a new run after the release is committed/pushed.

Passing automated tests is not a guarantee of zero defects or lag-free behavior on every Android device.
