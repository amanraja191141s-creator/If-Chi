# SA Calculator v98.82 — GST keypad and calculation micro-audit

## Source inspected
- User-provided Android screen recording: 720 × 1560 pixels, 45.14 seconds.
- Project source: v98.81 ZIP, including `index.html`, `assets/js/app.js`, `assets/css/app.css`, `assets/css/tool-reference-ui.css`, and the Android workflow.
- The supplied recording shows the **GST Calculator screen only**. It does not show the standard calculator expression editor, so no claim is made about expression cursor/start-position behavior from this recording.

## Observed keypad geometry
- 4 columns × 4 rows.
- Row 1: 7, 8, 9, AC.
- Row 2: 4, 5, 6, Backspace.
- Row 3: 1, 2, 3, Equals.
- Row 4: 00, 0, decimal point, with Equals spanning rows 3–4.
- At 720 × 1560 capture size, keypad occupies approximately y=820–1450 (about 630 px, 40% of frame); the bottom banner is outside the keypad.
- The source already used a viewport-relative dock. The update keeps the reference 42dvh portrait target, preserves a four-by-four grid, and fixes the landscape max-height conflict so the larger landscape target is not silently clipped.
- Keys are full grid cells with a tall equals action; AC and backspace are distinct actions.

## GST interaction flow visible in recording
1. Original Amount is the first active input.
2. With GST / Without GST selects whether the entered amount is pre-tax or GST-inclusive.
3. GST Rate accepts manual keypad entry; quick rates 5% and 18% are shortcuts.
4. Same State displays SGST + CGST; Different State displays IGST.
5. Equals commits the calculation and closes the keypad; tapping an input returns to editing.
6. Amount input is capped at 9 digits (₹99,99,99,999).

## Defects corrected
- **Mode-specific input label:** the amount field now changes to “Amount Including GST” in Without GST mode and returns to “Original Amount” in With GST mode.\n- **Inclusive result semantics:** the old result calculation used the inclusive amount as `Gross Amount` in code, while the reference recording displayed the extracted taxable/base amount under that label. This was semantically inconsistent. The result now explicitly shows GST Amount, Taxable Amount, split tax rows, and Gross Amount (including GST). For inclusive mode, entered amount is gross; tax is extracted as `gross × rate / (100 + rate)`; taxable amount is gross minus tax.
- **Rate limit mismatch:** recording feedback says GST rate must be less than 40%, while source allowed up to 100%. Validation now rejects 40% and above, both during keypad entry and calculation.
- **Missing-field equals guard:** pressing equals without an amount or GST rate now shows a specific prompt and leaves the keypad open; it does not reveal a blank result panel.\n- **GST AC/backspace blank state:** source forced a cleared GST field to literal zero, preventing its placeholder from returning. GST-specific AC/backspace now restore a truly empty field; non-GST tools retain their existing zero behavior.
- **GST decimal entry:** amount and rate keypad entry are limited to two fractional digits.
- **Responsive keypad clipping:** landscape used a 58dvh variable while retaining a 52dvh max-height. The max-height now follows the landscape target.

## Important source/recording differences
- The recording's toast at several points remains visible across multiple captured moments; toast display is time-based (2.2 seconds) in source. It may be retriggered by repeated invalid actions.
- The recording includes an ad banner at the bottom; it is not part of the keypad geometry.
- The recording does not demonstrate the general calculator's expression/result row. That area requires a separate recording of the standard calculator screen for visual verification.

## Validation
- Added v98.82 regression tests for GST inclusive/exclusive arithmetic semantics, 40% boundary, GST clear/backspace, keypad geometry, and workflow identity.
- Full Node test suite, syntax checks, web build, root/www synchronization, YAML parse, and ZIP integrity are recorded in the release verification report after execution.
- Physical Android rendering and remote GitHub Actions execution are not represented as passed unless separately run on-device / in GitHub.

## Standard calculator expression/result behavior — source inspection only
The uploaded recording does not show the standard calculator screen, but the supplied project source contains a separate expression editor:
- `#calc-expr` is the editable expression line. Its placeholder is `0`; the stored initial expression is empty (`STATE.calcExpr = ''`), with cursor and selection offsets initialized to 0. The first input therefore begins at cursor offset 0. The expression row is right-aligned, so newly entered text grows from the right-hand edge toward the left as the expression length increases.
- `#calc-val` is the separate live-preview line below the expression. It is populated only when there is an expression and live calculation is enabled.
- For a compound expression, `=` evaluates and commits the result. The result is displayed in the primary expression row, while the source expression and caret selection are retained in `STATE.calcResultExpression`.
- The first Backspace after `=` calls `restoreCalcExpressionFromResult()` and restores the original expression and caret; a subsequent Backspace edits the expression.
- A lone numeric literal is deliberately left editable when `=` is pressed; it is not unnecessarily converted into a committed result.
- AC clears expression, preview/result state, repeat-equals state and cursor selection.
- This behavior is source-verified and regression-tested; its exact visual placement was not visible in the GST-only recording.
